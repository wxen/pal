"""api/minimax - MiniMax API"""
