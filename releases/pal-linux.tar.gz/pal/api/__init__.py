"""pal module"""

